K&K NPC navigation snapshot (PandiO/knk-workspace#670), format 1
Route quarry-to-keep in world world_KNK-DEV, box 1391 36 -559 to 1505 96 -393, taken 2026-11-17T19:34:31.627858800Z by plugin 0.1.0+e69dba6a

manifest.json  the box, world, time, plugin version, counts and notes
route.json     the road line the NPC navigation plans for the route (floor points), its stretches,
               gate crossings and plaza junctions
roads.json     the road graph's nodes in the box and the edges that pass through it (whole)
domains.json   every Town, District, Structure and gate whose WorldGuard region touches the box: whole
               shape, parent, priority, knk-allow-entry / knk-allow-exit, the cached AllowEntry /
               AllowExit, and a gate's doors with open or closed
settings.json  the NPC navigation settings at the route's start and the layer each came from
world/         the region files (.mca) the box touches, at their path in the world folder, after a save

Replay: a scenario helper loads this zip in CI (PandiO/knk-workspace#670, link B1b).
