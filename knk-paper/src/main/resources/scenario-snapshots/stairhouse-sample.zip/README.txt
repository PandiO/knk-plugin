Sample NPC navigation snapshot made from knk-stairhouse.schem (tools/scenario-scenes/make_snapshot_sample.py, PandiO/knk-workspace#670).
